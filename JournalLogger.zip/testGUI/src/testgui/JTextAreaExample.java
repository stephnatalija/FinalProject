/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package testgui;

import java.awt.Component;

/**
 *
 * @author sstan
 */
public class JTextAreaExample extends Component {

    public JTextAreaExample() {
    }
    
}
